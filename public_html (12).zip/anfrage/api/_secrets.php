<?php
return [
  'SUPABASE_SERVICE_ROLE' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVsZWRrdWVnbWFyaXRtc2plamxtIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTU4OTkyOSwiZXhwIjoyMDg3MTY1OTI5fQ.YXRbn9JAmKWxxMNTjRbLnT47FbNJ40juOr0XCNVjwWU',
  'SMTP_PASS' => 'jale2233A@',
  'CRON_TOKEN_FOLLOWUP' => 'aB9x4Kf7mQ2wL8nR3jP6vT1yH5sD0eG',
  'CRON_TOKEN_PORTAL' => 'pW8xK3mN7vR2qL5jT9bF4hY6dA0cE1gS',

  // Stripe (fill in after creating Stripe account)
  'STRIPE_SECRET_KEY' => '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',       // sk_live_... or sk_test_...
  'STRIPE_WEBHOOK_SECRET' => 'whsec_jsr0EXHILEM8qQenPfclnfm3nEMIwhVU',   // whsec_...
  'STRIPE_PRICE_ID' => 'price_1TAGcJLYOZN39zSH6UCkPnqQ',         // price_... (99 EUR/month)
];
define('DEMO_CLEANUP_TOKEN', 'TOKEN234509TOKEN231');