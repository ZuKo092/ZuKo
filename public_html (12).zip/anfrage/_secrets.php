<?php
declare(strict_types=1);

/* Supabase */
ddefine('SUPABASE_URL', 'https://uledkuegmaritmsjejlm.supabase.co');
define('SUPABASE_SERVICE_ROLE', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVsZWRrdWVnbWFyaXRtc2plamxtIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTU4OTkyOSwiZXhwIjoyMDg3MTY1OTI5fQ.YXRbn9JAmKWxxMNTjRbLnT47FbNJ40juOr0XCNVjwWU'); // doar server
define('COMPANY_ID', '0632a3c1-2734-4303-9341-f1b2db7f977a');

/* Turnstile */
define('TURNSTILE_SECRET', '0x4AAAAAACle1_zjCDYvMcU6');
define('TURNSTILE_SITEKEY', '0x4AAAAAACle13sa9kUeLRUgGJq03ODNwM8'); // al tau

/* Email (optional) */
define('ENABLE_EMAIL_OWNER', true);
define('ENABLE_EMAIL_CLIENT', true);

define('MAIL_FROM', 'info@grapify.show');
define('MAIL_FROM_NAME', 'AnfrageBox');
define('OWNER_EMAIL', 'info@grapify.show');
define('BRAND_NAME', 'Umzug Transporte 84');